# OTP/PIN Field

## [See Live](https://codepen.io/hicoders/pen/oNEqJGO)

# Preview

![Preview](../.github/assets/otp-filed.png)
