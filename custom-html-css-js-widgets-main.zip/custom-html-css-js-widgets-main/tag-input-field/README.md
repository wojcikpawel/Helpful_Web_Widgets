# Tag Input

### [See Live](https://codepen.io/hicoders/pen/abqVZKM)

## Screenshot

![](../.github/assets/tag-input.png)
